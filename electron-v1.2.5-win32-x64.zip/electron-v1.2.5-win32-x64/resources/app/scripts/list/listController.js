(function () {
    'use strict';
    angular.module('app')
    .controller('listController', ['configService', 'listService', '$timeout', '$translate', '$location', '$q', '$http', '$scope', ListController]);

    function ListController(configService, listService, $timeout, $translate, $location, $q, $http, $scope) {
        console.log("> ListController()");

        /**
        * Variable declarations
        **/

        var self = this;
        self.fileListXml = [];
        self.fileListJson = [];
        self.selectedFileListXml = [];
        self.selectedFileListJson = [];
        self.selectedFolderNameXml = '';
        self.selectedFolderNameJson = '';
        self.selectedFolderPathXml = '';
        self.selectedFolderPathJson = '';
        self.loadingXml = false;
        self.loadingJson = false;
        self.queryXml = {
            order: 'name',
            limit: 5,
            page: 1
        };
        self.queryJson = {
            order: 'name',
            limit: 5,
            page: 1
        };

        /**
        * Exposed functions
        **/

        // fonction appelée lorsqu'un nouveau dossier
        // est sélectionné par l'utilisateur
        // ! impossible sans $scope pour le moment car Angular ne supporte
        // ! pas ng-model ni ng-change pour les balises input de type file
        $scope.chooseFolderXml = function (data) {
            console.log("> ListController() >> chooseFolderXml(data)",data);
            if (data && data[0] && data[0].name) {
                $scope.$apply(function(){
                    self.selectedFolderNameXml = data[0].name;
                    self.selectedFolderPathXml = data[0].path;
                    //appel au service
                    listService.setFolderPathXml(self.selectedFolderPathXml).then( function (response) {
                        scanFolderXml();
                    });
                });
            }
        };

        // fonction appelée lorsqu'un changement d'ordre
        // est demandé par l'utilisateur (md-data-table)
        self.onOrderChangeXml = function (order) {
            console.log("> ListController() >> onOrderChangeXml(order)",order);
            return listService.setOrderXml(order);
        };

        // fonction appelée lorsqu'un changement de page
        // est demandé par l'utilisateur (md-data-table)
        self.onPaginationChangeXml = function (page, limit) {
            console.log("> ListController() >> onPaginationChangeXml(page,limit)",page,limit);
            return listService.setPaginationXml(page,limit);
        };

        // fonction qui permet à l'utilisateur de pouvoir forcer
        // le rechargement du dossier XML
        self.refreshListXml = function () {
            console.log("> ListController() >> refreshListXml()");
            return scanFolderXml();
        }

        // fonction qui permet à l'utilisateur de changer la langue
        // de l'application (français ou anglais)
        self.setLang = function (lang) {
            console.log("> ListController() >> setLang(lang)",lang);
            var availableLangs = ['fr', 'en'];
            if (availableLangs.indexOf(lang) !== -1) {
                //on change la langue
                self.lang = lang;
                $translate.use(lang);
                configService.setLang(lang);
            }
        };
        
        // fonction qui permet à l'utilisateur de changer l'option minify
        self.setMinify = function () {
            console.log("> ListController() >> setMinify()");
            configService.setMinify(self.minify).then(function(response) {
                // console.log("mini set response",response);
            });
        };

        // fonction qui permet à l'utilisateur de lancer la transformation de XML vers JSON
        // des fichiers qu'il a sélectionné (self.selectedFileListXml) dans le tableau
        self.xmlToJsonSelectedFiles = function () {
            console.log("> ListController() >> xmlToJsonSelectedFiles()");
            self.loadingXml = true;
            var NumberOfRequests = self.selectedFileListXml.length;
            var NumberOfTerminatedRequests = 0;
            // on parcours tous les fichiers sélectionnés
            self.selectedFileListXml.forEach (function (element, index, array) {
                // on charge le fichier à tester
                var rawFile = new XMLHttpRequest();
                rawFile.open("GET", self.selectedFolderPathXml+"/"+element.name+"."+element.ext, true);
                rawFile.onreadystatechange = function () {
                    if(rawFile.readyState === 4) {
                        if(rawFile.status === 200 || rawFile.status == 0) {
                        // on donne le texte du fichier chargé au service d'analyse du poslog
                        listService.xmlToJson(element.name, rawFile.responseText, self.minify).then(function (response) {
                            if (response) {
                                // console.log("File converted");
                            } else {
                                //erreur lors de l'exécution de la fonction de conversion
                                console.error("ERROR while trying to convert the file.");
                            }
                            //si c'est la dernière requête, on désactive le loader
                            NumberOfTerminatedRequests++;
                            if (NumberOfTerminatedRequests >= NumberOfRequests) {
                                self.loadingXml = false;
                                scanFolderJson();
                            }
                        });
                        }
                    }
                }
                rawFile.send(null);
            });
        }
        
        /**
         * JSON
         */
        
        // fonction appelée lorsqu'un nouveau dossier
        // est sélectionné par l'utilisateur
        // ! impossible sans $scope pour le moment car Angular ne supporte
        // ! pas ng-model ni ng-change pour les balises input de type file
        $scope.chooseFolderJson = function (data) {
            console.log("> ListController() >> chooseFolderJson(data)",data);
            if (data && data[0] && data[0].name) {
                $scope.$apply(function(){
                    self.selectedFolderNameJson = data[0].name;
                    self.selectedFolderPathJson = data[0].path;
                    //appel au service
                    listService.setFolderPathJson(self.selectedFolderPathJson).then( function (response) {
                        scanFolderJson();
                    });
                });
            }
        };

        // fonction appelée lorsqu'un changement d'ordre
        // est demandé par l'utilisateur (md-data-table)
        self.onOrderChangeJson = function (order) {
            console.log("> ListController() >> onOrderChangeJson(order)",order);
            return listService.setOrderJson(order);
        };

        // fonction appelée lorsqu'un changement de page
        // est demandé par l'utilisateur (md-data-table)
        self.onPaginationChangeJson = function (page, limit) {
            console.log("> ListController() >> onPaginationChangeJson(page,limit)",page,limit);
            return listService.setPaginationJson(page,limit);
        };

        // fonction qui permet à l'utilisateur de pouvoir forcer
        // le rechargement du dossier XML
        self.refreshListJson = function () {
            console.log("> ListController() >> refreshListJson()");
            return scanFolderJson();
        }
        
        // fonction qui permet à l'utilisateur de lancer la transformation de XML vers JSON
        // des fichiers qu'il a sélectionné (self.selectedFileListJson) dans le tableau
        self.jsonToXmlSelectedFiles = function () {
            console.log("> ListController() >> xmlToJsonSelectedFiles()");
            self.loadingJson = true;
            var NumberOfRequests = self.selectedFileListJson.length;
            var NumberOfTerminatedRequests = 0;
            // on parcours tous les fichiers sélectionnés
            self.selectedFileListJson.forEach (function (element, index, array) {
                // on charge le fichier à tester
                var rawFile = new XMLHttpRequest();
                rawFile.open("GET", self.selectedFolderPathJson+"/"+element.name+"."+element.ext, true);
                rawFile.onreadystatechange = function () {
                    if(rawFile.readyState === 4) {
                        if(rawFile.status === 200 || rawFile.status == 0) {
                        // on donne le texte du fichier chargé au service d'analyse du poslog
                        listService.jsonToXml(element.name, rawFile.responseText, self.minify).then(function (response) {
                            if (response) {
                                // console.log("File converted");
                            } else {
                                //erreur lors de l'exécution de la fonction de conversion
                                console.error("ERROR while trying to convert the file.");
                            }
                            //si c'est la dernière requête, on désactive le loader
                            NumberOfTerminatedRequests++;
                            if (NumberOfTerminatedRequests >= NumberOfRequests) {
                                self.loadingJson = false;
                                scanFolderXml();
                            }
                        });
                        }
                    }
                }
                rawFile.send(null);
            });
        }

        /**
        * Internal functions
        **/

        // fonction qui scan le dossier configuré dans le service
        function scanFolderXml () {
            console.log("> ListController() >> scanFolderXml()");
            listService.getFileListXml().then(function (response) {
                if (response && response.success && response.fileList) {
                    //on stocke les infos reçues
                    self.fileListXml = response.fileList;
                    self.numberOfFilesXml = self.fileListXml.length;
                    self.selectedFileListXml = [];
                } else {
                    //si aucun fichier n'a été trouvé dans le dossier, on réinitialise la liste
                    self.fileListXml = [];
                    self.numberOfFilesXml = self.fileListXml.length;
                    self.selectedFileListXml = [];
                }
            });
        };
        
        // fonction qui scan le dossier configuré dans le service
        function scanFolderJson () {
            console.log("> ListController() >> scanFolderJson()");
            listService.getFileListJson().then(function (response) {
                if (response && response.success && response.fileList) {
                    //on stocke les infos reçues
                    self.fileListJson = response.fileList;
                    self.numberOfFilesJson = self.fileListJson.length;
                    self.selectedFileListJson = [];
                } else {
                    //si aucun fichier n'a été trouvé dans le dossier, on réinitialise la liste
                    self.fileListJson = [];
                    self.numberOfFilesJson = self.fileListJson.length;
                    self.selectedFileListJson = [];
                }
            });
        };

        // fonction d'initialisation
        // permet d'initialiser self.selectedFolderPathXml et self.selectedFolderNameXml
        // permet d'initialiser self.selectedFolderPathJson et self.selectedFolderNameJson
        function init () {
            console.log("> ListController() >> init()");
            configService.getLang().then(function (response) {
                self.setLang(response.lang);
            });
            configService.getMinify().then(function (response) {
                // console.log("mini response",response);
                self.minify = response.minify;
                // console.log("mini self.minify",self.minify);
            });
            listService.getFolderPathXml().then(function (response) {
                if (response && response.path) {
                    self.selectedFolderPathXml = response.path;
                    if (self.selectedFolderPathXml.indexOf("/") !== -1) {
                        self.selectedFolderNameXml = response.path.split("/");
                        self.selectedFolderNameXml = self.selectedFolderNameXml[self.selectedFolderNameXml.length - 1];
                    } else {
                        self.selectedFolderNameXml = response.path.split("\\");
                        self.selectedFolderNameXml = self.selectedFolderNameXml[self.selectedFolderNameXml.length - 1];
                    }
                    scanFolderXml();
                } else {
                    console.error("ERROR while getting folder path !");
                }
                listService.getFolderPathJson().then(function (response) {
                    if (response && response.path) {
                        self.selectedFolderPathJson = response.path;
                        if (self.selectedFolderPathJson.indexOf("/") !== -1) {
                            self.selectedFolderNameJson = response.path.split("/");
                            self.selectedFolderNameJson = self.selectedFolderNameJson[self.selectedFolderNameJson.length - 1];
                        } else {
                            self.selectedFolderNameJson = response.path.split("\\");
                            self.selectedFolderNameJson = self.selectedFolderNameJson[self.selectedFolderNameJson.length - 1];
                        }
                        scanFolderJson();
                    } else {
                        console.error("ERROR while getting folder path !");
                    }
                });
            });
        }
        init();

    }

})();
