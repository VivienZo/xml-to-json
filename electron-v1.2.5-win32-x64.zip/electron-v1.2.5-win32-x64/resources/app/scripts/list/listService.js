(function () {
    'use strict';
    angular.module('app')
    .service('listService', ['configService', '$q', '$location', ListService]);

    function ListService(configService, $q, $location) {
        console.log("> ListService()");

        /**
        * Variable declarations
        **/

        var self = this;
        self.folderPathXml = "";
        self.orderXml = "",
        self.pageXml = 1;
        self.limitXml = 5;
        self.folderPathJson = "";
        self.orderJson = "",
        self.pageJson = 1;
        self.limitJson = 5;
        var fs = require('fs');
        var x2js = new X2JS();

        /**
        * Exposed functions
        **/

        return {
            getFileListXml: getFileListXml,
            getFolderPathXml: getFolderPathXml,
            setFolderPathXml: setFolderPathXml,
            getOrderXml: getOrderXml,
            setOrderXml: setOrderXml,
            getPaginationXml: getPaginationXml,
            setPaginationXml: setPaginationXml,
            xmlToJson: xmlToJson,
            getFileListJson: getFileListJson,
            getFolderPathJson: getFolderPathJson,
            setFolderPathJson: setFolderPathJson,
            getOrderJson: getOrderJson,
            setOrderJson: setOrderJson,
            getPaginationJson: getPaginationJson,
            setPaginationJson: setPaginationJson,
            jsonToXml: jsonToXml
        };

        /**
        * Internal functions
        **/

        
        /**
         * ----------
         * XML
         * ----------
         */
        
        // fonction permettant de récupérer les fichiers XML présents
        // dans le dossier configuré par l'utilisateur
        function getFileListXml () {
            console.log("> ListService() >> getFileListXml()");
            var deferred = $q.defer();
            var folderContents = require('folder-contents');
            var options = {
                "path": self.folderPathXml,
                "separator":".",
                "recursively":false,
                "method":"simple",
                "useBasePath":true,
                "filter":{
                    "extensionIgnore":[],
                    "extensionAccept":[],
                    "folderIgnore":[],
                    "fileIgnore":[]
                },
                "date":true, // See doc for patterns and i18n
                "size":true, // See doc for patterns and i18n
                "useFullPath":false
            };
            var jsonResult = folderContents(options);
            // console.log("jsonResult",jsonResult);
            if (jsonResult && jsonResult['.files']) {
                // fonction interne indiquant si le fichier fourni est un XML
                function isXML (element) {
                return (element.ext == "xml");
                }
                // fonction interne permettant de transformer la taille d'un fichier
                // de Bytes en Kilo-Bytes
                function bytesToKiloBytes (element) {
                var updatedElement = element;
                updatedElement.size = +(updatedElement.size / 1000).toFixed(2);
                return updatedElement;
                }
                var fileList  = jsonResult['.files'].filter(isXML).map(bytesToKiloBytes);
                deferred.resolve({
                success         : true,
                fileList        : fileList
                });
            } else {
                deferred.resolve({
                success         : true,
                fileList        : []
                });
            }
            return deferred.promise;
        }

        

        // fonction permettant de récupérer le chemin
        // vers le dossier d'analyse par lot
        function getFolderPathXml () {
            console.log("> ListService() >> getFolderPathXml()");
            var deferred = $q.defer();
            //si un chemin est déjà configuré, on prend celui-ci en compte
            if (self.folderPathXml && self.folderPathXml.length) {
                deferred.resolve({
                success: true,
                path: self.folderPathXml
                });
            } else {
                //sinon on va chercher si un chemin est configuré en base de données
                configService.getFolderPathXml().then(function (response) {
                if (response && response.success && response.folderPath) {
                    //si oui, on le reprend
                    self.folderPathXml = response.folderPath;
                    deferred.resolve({
                    success: true,
                    path: self.folderPathXml
                    });
                } else {
                    //si non, on initialise le chemin
                    self.folderPathXml = $location.absUrl().replace("file:///","").split("/");
                    var urlSplitLength = self.folderPathXml.length;
                    var indexOfRootFolder = self.folderPathXml.indexOf("resources");
                    self.folderPathXml.splice(indexOfRootFolder, (urlSplitLength - indexOfRootFolder));
                    self.folderPathXml.push("poslog_files");
                    self.folderPathXml = self.folderPathXml.join("/");
                    //on vérifie si un dossier existe à ce chemin
                    //s'il n'existe pas, on le crée
                    fs.mkdir(self.folderPathXml, function(err) {
                    // EEXIST -> dossier existe déjà
                    if (err && err.code !== 'EEXIST') {
                        console.error("Error during the creation of the folder poslog_files : ",err);
                    } else {
                        //on crée les 2 sous-dossiers xml et json
                        fs.mkdir(self.folderPathXml+"/xml", function(err) {
                            // EEXIST -> dossier existe déjà
                            if (err && err.code !== 'EEXIST') {
                                console.error("Error during the creation of the folder poslog_files/xml : ",err);
                            }
                        });
                        fs.mkdir(self.folderPathXml+"/json", function(err) {
                            // EEXIST -> dossier existe déjà
                            if (err && err.code !== 'EEXIST') {
                                console.error("Error during the creation of the folder poslog_files/json : ",err);
                            }
                            
                        });
                        self.folderPathXml = self.folderPathXml + "/xml";
                        //on enregistre le chemin en base de données
                        configService.setFolderPathXml(self.folderPathXml).then(function (response) {
                            deferred.resolve({
                                success: true,
                                path: self.folderPathXml
                            });
                        });
                    }
                    });
                }
                });
            }
            return deferred.promise;
        };

        // fonction permettant d'écraser le chemin du dossier
        // d'analyse par lot avec celui passé en paramètre
        function setFolderPathXml (path) {
            console.log("> ListService() >> setFolderPathXml(path)",path);
            var deferred = $q.defer();
            if (typeof path === 'string') {
                self.folderPathXml = path;
                //on enregistre le chemin en base de données
                configService.setFolderPathXml(self.folderPathXml).then(function (response) {
                deferred.resolve({
                    success: true,
                    path: self.folderPathXml
                });
                });
            } else {
                deferred.resolve({
                success: false,
                path: self.folderPathXml
                });
            }
            return deferred.promise;
        };

        // fonction permettant de récupérer les paramètres
        // d'ordre utilisés par l'utilisateur
        function getOrderXml () {
            console.log("> ListService() >> getOrderXml()");
            var deferred = $q.defer();
            deferred.resolve({
                success: true,
                order: self.orderXml
            });
            return deferred.promise;
        };

        // fonction permettant de sauvegarder les paramètres
        // d'ordre utilisés par l'utilisateur
        function setOrderXml (order) {
            console.log("> ListService() >> setOrder(order)",order);
            var deferred = $q.defer();
            if (typeof order === 'string') {
                self.orderXml = order;
                deferred.resolve({
                success: true,
                order: self.orderXml
                });
            } else {
                deferred.resolve({
                success: false,
                message: "Invalid param : order has to be a string.",
                order: self.orderXml
                });
            }
            return deferred.promise;
        };

        // fonction permettant de récupérer les paramètres
        // de pagination utilisés par l'utilisateur
        function getPaginationXml () {
            console.log("> ListService() >> getPagination()");
            var deferred = $q.defer();
            deferred.resolve({
                success: true,
                page: self.pageXml,
                limit: self.limitXml
            });
            return deferred.promise;
        };

        // fonction permettant de sauvegarder les paramètres
        // de pagination utilisés par l'utilisateur
        function setPaginationXml (page, limit) {
            console.log("> ListService() >> setPagination(page, limit)",page,limit);
            var deferred = $q.defer();
            if (typeof page === "number" && typeof limit === "number") {
                self.pageXml = page;
                self.limitXml = limit;
                deferred.resolve({
                success: true,
                page: self.pageXml,
                limit: self.limitXml
                });
            } else {
                deferred.resolve({
                success: false,
                page: self.pageXml,
                limit: self.limitXml
                });
            }
            return deferred.promise;
        };
        
        // fonction permettant de convertir un XML (contenu reçu en paramètre)
        // en JSON et d'enregistrer le résultat dans un fichier .json
        function xmlToJson (fileName, xmlCode, minify) {
            // console.log("> ListService() >> xmlToJson()");
            var deferred = $q.defer();
            if (minify) {
                fs.writeFile(self.folderPathJson+"/_"+fileName+".json", vkbeautify.jsonmin(JSON.stringify(x2js.xml_str2json(xmlCode))), function(err) {
                    if (err) {
                        return console.error(err);
                    }
                    // console.log("Pretty file saved");
                    deferred.resolve({
                        success: true
                    });
                });
            } else {
                fs.writeFile(self.folderPathJson+"/_"+fileName+".json", vkbeautify.json(JSON.stringify(x2js.xml_str2json(xmlCode))), function(err) {
                    if (err) {
                        return console.error(err);
                    }
                    // console.log("Minify file saved");
                    deferred.resolve({
                        success: true
                    });
                });
            }
            return deferred.promise;
        };
        
        
        /**
         * ----------
         * JSON
         * ----------
         */
        
        // fonction permettant de récupérer les fichiers JSON présents
        // dans le dossier configuré par l'utilisateur
        function getFileListJson () {
            console.log("> ListService() >> getFileListJson()");
            var deferred = $q.defer();
            var folderContents = require('folder-contents');
            var options = {
                "path": self.folderPathJson,
                "separator":".",
                "recursively":false,
                "method":"simple",
                "useBasePath":true,
                "filter":{
                    "extensionIgnore":[],
                    "extensionAccept":[],
                    "folderIgnore":[],
                    "fileIgnore":[]
                },
                "date":true, // See doc for patterns and i18n
                "size":true, // See doc for patterns and i18n
                "useFullPath":false
            };
            var jsonResult = folderContents(options);
            // console.log("jsonResult",jsonResult);
            if (jsonResult && jsonResult['.files']) {
                // fonction interne indiquant si le fichier fourni est un JSON
                function isJSON (element) {
                    return (element.ext == "json");
                }
                // fonction interne permettant de transformer la taille d'un fichier
                // de Bytes en Kilo-Bytes
                function bytesToKiloBytes (element) {
                var updatedElement = element;
                updatedElement.size = +(updatedElement.size / 1000).toFixed(2);
                return updatedElement;
                }
                var fileList  = jsonResult['.files'].filter(isJSON).map(bytesToKiloBytes);
                deferred.resolve({
                success         : true,
                fileList        : fileList
                });
            } else {
                deferred.resolve({
                success         : true,
                fileList        : []
                });
            }
            return deferred.promise;
        }

        

        // fonction permettant de récupérer le chemin
        // vers le dossier d'analyse par lot
        function getFolderPathJson () {
            console.log("> ListService() >> getFolderPathJson()");
            var deferred = $q.defer();
            //si un chemin est déjà configuré, on prend celui-ci en compte
            if (self.folderPathJson && self.folderPathJson.length) {
                deferred.resolve({
                success: true,
                path: self.folderPathJson
                });
            } else {
                //sinon on va chercher si un chemin est configuré en base de données
                configService.getFolderPathJson().then(function (response) {
                if (response && response.success && response.folderPath) {
                    //si oui, on le reprend
                    self.folderPathJson = response.folderPath;
                    deferred.resolve({
                    success: true,
                    path: self.folderPathJson
                    });
                } else {
                    //si non, on initialise le chemin
                    self.folderPathJson = $location.absUrl().replace("file:///","").split("/");
                    var urlSplitLength = self.folderPathJson.length;
                    var indexOfRootFolder = self.folderPathJson.indexOf("resources");
                    self.folderPathJson.splice(indexOfRootFolder, (urlSplitLength - indexOfRootFolder));
                    self.folderPathJson.push("poslog_files");
                    self.folderPathJson = self.folderPathJson.join("/");
                    //on vérifie si un dossier existe à ce chemin
                    //s'il n'existe pas, on le crée
                    fs.mkdir(self.folderPathJson, function(err) {
                    // EEXIST -> dossier existe déjà
                    if (err && err.code !== 'EEXIST') {
                        console.error("Error during the creation of the folder poslog_files : ",err);
                    } else {
                        //on crée les 2 sous-dossiers xml et json
                        fs.mkdir(self.folderPathJson+"/xml", function(err) {
                            // EEXIST -> dossier existe déjà
                            if (err && err.code !== 'EEXIST') {
                                console.error("Error during the creation of the folder poslog_files/xml : ",err);
                            }
                        });
                        fs.mkdir(self.folderPathJson+"/json", function(err) {
                            // EEXIST -> dossier existe déjà
                            if (err && err.code !== 'EEXIST') {
                                console.error("Error during the creation of the folder poslog_files/json : ",err);
                            }
                            
                        });
                        self.folderPathJson = self.folderPathJson + "/json";
                        //on enregistre le chemin en base de données
                        configService.setFolderPathJson(self.folderPathJson).then(function (response) {
                            deferred.resolve({
                                success: true,
                                path: self.folderPathJson
                            });
                        });
                    }
                    });
                }
                });
            }
            return deferred.promise;
        };

        // fonction permettant d'écraser le chemin du dossier
        // d'analyse par lot avec celui passé en paramètre
        function setFolderPathJson (path) {
            console.log("> ListService() >> setFolderPathJson(path)",path);
            var deferred = $q.defer();
            if (typeof path === 'string') {
                self.folderPathJson = path;
                //on enregistre le chemin en base de données
                configService.setFolderPathJson(self.folderPathJson).then(function (response) {
                deferred.resolve({
                    success: true,
                    path: self.folderPathJson
                });
                });
            } else {
                deferred.resolve({
                success: false,
                path: self.folderPathJson
                });
            }
            return deferred.promise;
        };

        // fonction permettant de récupérer les paramètres
        // d'ordre utilisés par l'utilisateur
        function getOrderJson () {
            console.log("> ListService() >> getOrderJson()");
            var deferred = $q.defer();
            deferred.resolve({
                success: true,
                order: self.orderJson
            });
            return deferred.promise;
        };

        // fonction permettant de sauvegarder les paramètres
        // d'ordre utilisés par l'utilisateur
        function setOrderJson (order) {
            console.log("> ListService() >> setOrder(order)",order);
            var deferred = $q.defer();
            if (typeof order === 'string') {
                self.orderJson = order;
                deferred.resolve({
                success: true,
                order: self.orderJson
                });
            } else {
                deferred.resolve({
                success: false,
                message: "Invalid param : order has to be a string.",
                order: self.orderJson
                });
            }
            return deferred.promise;
        };

        // fonction permettant de récupérer les paramètres
        // de pagination utilisés par l'utilisateur
        function getPaginationJson () {
            console.log("> ListService() >> getPagination()");
            var deferred = $q.defer();
            deferred.resolve({
                success: true,
                page: self.pageJson,
                limit: self.limitJson
            });
            return deferred.promise;
        };

        // fonction permettant de sauvegarder les paramètres
        // de pagination utilisés par l'utilisateur
        function setPaginationJson (page, limit) {
            console.log("> ListService() >> setPagination(page, limit)",page,limit);
            var deferred = $q.defer();
            if (typeof page === "number" && typeof limit === "number") {
                self.pageJson = page;
                self.limitJson = limit;
                deferred.resolve({
                success: true,
                page: self.pageJson,
                limit: self.limitJson
                });
            } else {
                deferred.resolve({
                success: false,
                page: self.pageJson,
                limit: self.limitJson
                });
            }
            return deferred.promise;
        };
        
        // fonction permettant de convertir un JSON (contenu reçu en paramètre)
        // en XML et d'enregistrer le résultat dans un fichier .xml
        function jsonToXml (fileName, jsonCode, minify) {
            // console.log("> ListService() >> jsonToXml()");
            var deferred = $q.defer();
            if (minify) {
                fs.writeFile(self.folderPathXml+"/_"+fileName+".xml", vkbeautify.xmlmin(x2js.json2xml_str(JSON.parse(jsonCode))), function(err) {
                    if (err) {
                        return console.error(err);
                    }
                    // console.log("File saved");
                    deferred.resolve({
                        success: true
                    });
                });
            } else {
                fs.writeFile(self.folderPathXml+"/_"+fileName+".xml", vkbeautify.xml(x2js.json2xml_str(JSON.parse(jsonCode))), function(err) {
                    if (err) {
                        return console.error(err);
                    }
                    // console.log("File saved");
                    deferred.resolve({
                        success: true
                    });
                });
            }
            return deferred.promise;
        };

    }
})();
