(function() {
  'use strict';

  var _templateBase = './scripts';

  angular.module('app', [
      'ngRoute',
      'ngMaterial',
      'ngAnimate',
      'ngMdIcons',
      'md.data.table',
      'pascalprecht.translate',
      'ng-polymer-elements'
    ])
    .config(['$routeProvider', function($routeProvider) {
      $routeProvider.when('/', {
        templateUrl: _templateBase + '/list/list.html',
        controller: 'listController',
        controllerAs: '_ctrl'
      });
      $routeProvider.otherwise({
        redirectTo: '/'
      });
    }])
    .config(function($translateProvider) {
      $translateProvider.translations('en', {
        APP_TITLE1: 'XML ',
        APP_TITLE2: ' JSON',
        MENU_LANG: 'Language',
        TABLE_TITLE_LIST1: 'List of files: ',
        TABLE_TITLE_LIST2: 'XML',
        TABLE_TITLE_LIST3: 'JSON',
        NO_SELECTED_FILES_XML: 'No selected XML',
        COUNT_SELECTED_XML1: 'selected XML',
        COUNT_SELECTED_XML2: 'selected XML',
        NO_SELECTED_FILES_JSON: 'No selected JSON',
        COUNT_SELECTED_JSON1: 'selected JSON',
        COUNT_SELECTED_JSON2: 'selected JSON',
        FILE_NAME: 'File name',
        FILE_SIZE: 'File size',
        FILE_SIZE_UNIT: 'kB',
        SEARCH_LIST_PLACEHOLDER: 'Search...',
        REFRESH_BUTTON: 'Refresh',
        CHOOSE_FOLDER_BUTTON: 'Choose a target folder...'
      });
      $translateProvider.translations('fr', {
        APP_TITLE1: 'XML ',
        APP_TITLE2: ' JSON',
        MENU_LANG: 'Langue',
        TABLE_TITLE_LIST1: 'Liste des fichiers ',
        TABLE_TITLE_LIST2: 'XML',
        TABLE_TITLE_LIST3: 'JSON',
        NO_SELECTED_FILES_XML: 'Aucun XML sélectionné',
        COUNT_SELECTED_XML1: 'XML sélectionné',
        COUNT_SELECTED_XML2: 'XML sélectionnés',
        NO_SELECTED_FILES_JSON: 'Aucun JSON sélectionné',
        COUNT_SELECTED_JSON1: 'JSON sélectionné',
        COUNT_SELECTED_JSON2: 'JSON sélectionnés',
        FILE_NAME: 'Nom du fichier',
        FILE_SIZE: 'Taille du fichier',
        FILE_SIZE_UNIT: 'ko',
        SEARCH_LIST_PLACEHOLDER: 'Rechercher...',
        REFRESH_BUTTON: 'Rafraichir',
        CHOOSE_FOLDER_BUTTON: 'Sélectionnez un dossier...'
      });
      $translateProvider.preferredLanguage('en');
    })
    .config(function($mdThemingProvider) {
      $mdThemingProvider.theme('default')
        .primaryPalette('indigo')
        .accentPalette('orange')
        .warnPalette('red');
    })
    .directive('elastic', [
      '$timeout',
      function($timeout) {
        return {
          restrict: 'A',
          link: function($scope, element) {
            $scope.initialHeight = $scope.initialHeight || element[0].style.height;
            var resize = function() {
              element[0].style.height = $scope.initialHeight;
              element[0].style.height = "" + element[0].scrollHeight + "px";
            };
            element.on("input change", resize);
            $timeout(resize, 0);
          }
        };
      }
    ])
    .filter('to_trusted', ['$sce', function($sce){
        return function(text) {
            return $sce.trustAsHtml(text);
        };
    }]);

})();
