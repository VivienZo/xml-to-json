(function () {
  'use strict';
  angular.module('app')
  .service('configService', ['$q', ConfigService]);

  function ConfigService($q) {
    console.log("> ConfigService()");

    /**
    * Variable declarations
    **/

    var self = this;
    self.lang = "";
    self.minify = false;
    self.folderPathXml = "";
    self.folderPathJson = "";
    var db = new Nedb({ filename: 'datafile', autoload: true });

    /**
    * Exposed functions
    **/

    return {
        getLang: getLang,
        setLang: setLang,
        getMinify: getMinify,
        setMinify: setMinify,
        getFolderPathXml: getFolderPathXml,
        setFolderPathXml: setFolderPathXml,
        getFolderPathJson: getFolderPathJson,
        setFolderPathJson: setFolderPathJson,
        cleanDb: cleanDb
    };

    function cleanDb () {
      console.log("> ConfigService() >> cleanDb()");
      var deferred = $q.defer();
      db.find({}, function (err, docs) {
        console.log("> ConfigService() >> cleanDb() >>> before clean : ",docs);
        db.remove({}, { multi: true }, function (err, numRemoved) {
          console.log("> ConfigService() >> cleanDb() >>> "+numRemoved+" items has been removed.");
          db.find({}, function (err, docs) {
            console.log("> ConfigService() >> cleanDb() >>> after clean : ",docs);
            deferred.resolve({
              success: true
            });
          });
        });
      });
      return deferred.promise;
    }


    function getLang () {
      console.log("> ConfigService() >> getLang()");
      var deferred = $q.defer();
      // db.find({}, function (err, docs) {
      //   console.log("find all ",docs);
      // });
      db.findOne({config: 'userConfig'}, function (err, doc) {
        // console.log("=========> doc : ",doc);
        // console.log("=========> err : ",err);
        if (err) {
          deferred.resolve({
            success: false,
            lang: "en",
            message: err
          });
        } else if (!doc || !doc.lang) {
          deferred.resolve({
            success: false,
            lang: "en",
            message: "Lang not found."
          });
        } else {
          deferred.resolve({
            success: true,
            lang: doc.lang
          });
        }
      });
      return deferred.promise;
    };


    function setLang (_lang) {
      console.log("> ConfigService() >> setLang(lang)",_lang);
      var deferred = $q.defer();
      if (_lang && typeof _lang === 'string' && _lang.length) {
        db.update({ config: 'userConfig' }, { $set: { lang: _lang } }, { upsert: true }, function (err, numReplaced, upsert) {
          // console.log("=========> err : ",err);
          // console.log("=========> numReplaced : ",numReplaced);
          // console.log("=========> upsert : ",upsert);
          deferred.resolve({
            success: true,
            lang: _lang
          });
        });
      } else {
        deferred.resolve({
          success: false,
          lang: "en",
          message: "Invalid argument lang."
        });
      }
      return deferred.promise;
    };
    
    function getMinify () {
      console.log("> ConfigService() >> getMinify()");
      var deferred = $q.defer();
      db.findOne({config: 'userConfig'}, function (err, doc) {
        if (err) {
          deferred.resolve({
            success: false,
            minify: true,
            message: err
          });
        } else if (!doc || typeof doc.minify !== 'boolean') {
          deferred.resolve({
            success: false,
            minify: true,
            message: "Minify not found."
          });
        } else {
          deferred.resolve({
            success: true,
            minify: doc.minify
          });
        }
      });
      return deferred.promise;
    };


    function setMinify (_minify) {
      console.log("> ConfigService() >> setMinify(minify)",_minify);
      var deferred = $q.defer();
      if (typeof _minify === 'boolean') {
        db.update({ config: 'userConfig' }, { $set: { minify: _minify } }, { upsert: true }, function (err, numReplaced, upsert) {
          deferred.resolve({
            success: true,
            minify: _minify
          });
        });
      } else {
        deferred.resolve({
          success: false,
          minify: true,
          message: "Invalid argument minify."
        });
      }
      return deferred.promise;
    };


    function getFolderPathXml () {
      console.log("> ConfigService() >> getFolderPathXml()");
      var deferred = $q.defer();
      db.findOne({config: 'userConfig'}, function (err, doc) {
        if (err) {
          deferred.resolve({
            success: false,
            folderPath: "",
            message: err
          });
        } else if (!doc || !doc.folderPathXml) {
          deferred.resolve({
            success: false,
            folderPath: "",
            message: "FolderPathXml not found."
          });
        } else {
          deferred.resolve({
            success: true,
            folderPath: doc.folderPathXml
          });
        }
      });
      return deferred.promise;
    };


    function setFolderPathXml (_folderPath) {
      console.log("> ConfigService() >> setFolderPathXml(folderPath)",_folderPath);
      var deferred = $q.defer();
      if (_folderPath && typeof _folderPath === 'string') {
        db.update({ config: 'userConfig' }, { $set: { folderPathXml: _folderPath } }, { upsert: true }, function (err, numReplaced, upsert) {
          // console.log("=========> err : ",err);
          // console.log("=========> numReplaced : ",numReplaced);
          // console.log("=========> upsert : ",upsert);
          deferred.resolve({
            success: true,
            folderPath: _folderPath
          });
        });
      } else {
        deferred.resolve({
          success: false,
          folderPath: "",
          message: "Invalid argument folderPath."
        });
      }
      return deferred.promise;
    };
    
    function getFolderPathJson () {
      console.log("> ConfigService() >> getFolderPathJson()");
      var deferred = $q.defer();
      // db.find({}, function (err, docs) {
      //   console.log("find all ",docs);
      // });
      db.findOne({config: 'userConfig'}, function (err, doc) {
        // console.log("=========> doc : ",doc);
        // console.log("=========> err : ",err);
        if (err) {
          deferred.resolve({
            success: false,
            folderPath: "",
            message: err
          });
        } else if (!doc || !doc.folderPathJson) {
          deferred.resolve({
            success: false,
            folderPath: "",
            message: "FolderPathJson not found."
          });
        } else {
          deferred.resolve({
            success: true,
            folderPath: doc.folderPathJson
          });
        }
      });
      return deferred.promise;
    };


    function setFolderPathJson (_folderPath) {
      console.log("> ConfigService() >> setFolderPathJson(folderPath)",_folderPath);
      var deferred = $q.defer();
      if (_folderPath && typeof _folderPath === 'string') {
        db.update({ config: 'userConfig' }, { $set: { folderPathJson: _folderPath } }, { upsert: true }, function (err, numReplaced, upsert) {
          // console.log("=========> err : ",err);
          // console.log("=========> numReplaced : ",numReplaced);
          // console.log("=========> upsert : ",upsert);
          deferred.resolve({
            success: true,
            folderPath: _folderPath
          });
        });
      } else {
        deferred.resolve({
          success: false,
          folderPath: "",
          message: "Invalid argument folderPath."
        });
      }
      return deferred.promise;
    };

  }
})();
